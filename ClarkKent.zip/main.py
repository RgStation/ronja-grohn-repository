import time
time.sleep(0.1) # Wait for USB to become ready

for i in range(10):
    print(i)
name = input("Enter your name: ")

if name == "Clark Kent":
    print("You are the Superman!")
else:
    print("You are an ordinary person.")